package com.mediaplayer.ui;

public interface SoundProgressChangeListner {
    void onchange(int progress);
}
